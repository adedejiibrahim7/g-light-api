<?php
/**
 * Created by PhpStorm.
 * User: FIZZLE31
 * Date: 8/26/2018
 * Time: 7:38 PM
 */

//EGBON, NO NEED USING THIS, THE 'get_user.php' FILE ALREADY COVERS FOR ALL


header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age:3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorisation, X-Requested-With");
header("Authorisation: jfdlighirhtglfughiufdh");

include_once '../config/database.php';
include_once '../objects/user.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);
//
$test_data = array(
"email"  => "example@emaol.com",
"password" => "hbshhusgfyytrhbcjjruitojfhuyt"
);
$j = json_encode($test_data);
print_r($j);
//$data = json_decode($j);
//print_r($data);

//$data = json_decode(file_get_contents("php:input"));

// $user->email = $data->email;
// $user->password = $data->password;

// $user->getUser();