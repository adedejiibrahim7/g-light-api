<?php
class Database{
    public "host_name";
    public "db_name";
    public "username";
    public "pass_word";

    public conn;

    public __construct($conn){
        $this->conn = $conn;
    }

    try{
        
    }
}