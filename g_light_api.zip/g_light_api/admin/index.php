<?php
require 'static/header.php';
?>

<div class="wrapper row center">
    <div class="col-sm-4">
        <div class="panel-div">
            <h1>Text</h1>
        </div>
    </div>
    
    <div class="col-sm-4">
        <div class="panel-div">
            <h1>Text</h1>
        </div>
    </div>

    <div class="col-sm-4">
        <div class="panel-div">
            <h1>Text</h1>
        </div>
    </div>
</div>