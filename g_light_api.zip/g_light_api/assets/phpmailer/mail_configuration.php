<?php 
	require 'PHPMailerAutoload.php';
	$mail = new PHPMailer;
 ?>